package com.example.start.email;

public class EmailConfig {
    public static final String EMAIL ="emailsendercode";
    public static final String PASSWORD ="89231118313";
}
