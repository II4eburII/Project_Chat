package com.example.start.ui.main.main;

import com.example.start.data.Message;

public interface AdapterListener {
    public void clickOnItem(Message message);
}